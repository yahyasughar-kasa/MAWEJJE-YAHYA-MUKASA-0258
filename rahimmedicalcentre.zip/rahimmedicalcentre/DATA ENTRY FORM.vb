﻿Public Class DATA_ENTRY_FORM
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles lblBasicpay.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

    End Sub

    Private Sub DATA_ENTRY_FORM_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtMedicalAllowance_TextChanged(sender As Object, e As EventArgs) Handles txtMedicalAllowance.TextChanged

    End Sub
End Class