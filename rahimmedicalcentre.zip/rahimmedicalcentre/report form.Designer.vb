﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class report_form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtGrosspay = New TextBox()
        txtNetpay = New TextBox()
        lblGrosspay = New Label()
        lblNetpay = New Label()
        btnBack = New Button()
        SuspendLayout()
        ' 
        ' txtGrosspay
        ' 
        txtGrosspay.Location = New Point(171, 54)
        txtGrosspay.Name = "txtGrosspay"
        txtGrosspay.Size = New Size(168, 23)
        txtGrosspay.TabIndex = 5
        ' 
        ' txtNetpay
        ' 
        txtNetpay.Location = New Point(171, 111)
        txtNetpay.Name = "txtNetpay"
        txtNetpay.Size = New Size(168, 23)
        txtNetpay.TabIndex = 6
        ' 
        ' lblGrosspay
        ' 
        lblGrosspay.AutoSize = True
        lblGrosspay.Location = New Point(72, 54)
        lblGrosspay.Name = "lblGrosspay"
        lblGrosspay.Size = New Size(58, 15)
        lblGrosspay.TabIndex = 7
        lblGrosspay.Text = "Gross pay"
        ' 
        ' lblNetpay
        ' 
        lblNetpay.AutoSize = True
        lblNetpay.Location = New Point(72, 114)
        lblNetpay.Name = "lblNetpay"
        lblNetpay.Size = New Size(48, 15)
        lblNetpay.TabIndex = 8
        lblNetpay.Text = "Net pay"
        ' 
        ' btnBack
        ' 
        btnBack.Location = New Point(199, 186)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(128, 60)
        btnBack.TabIndex = 9
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = True
        ' 
        ' report_form
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(800, 450)
        Controls.Add(btnBack)
        Controls.Add(lblNetpay)
        Controls.Add(lblGrosspay)
        Controls.Add(txtNetpay)
        Controls.Add(txtGrosspay)
        Name = "report_form"
        Text = "report_form"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtGrosspay As TextBox
    Friend WithEvents txtNetpay As TextBox
    Friend WithEvents lblGrosspay As Label
    Friend WithEvents lblNetpay As Label
    Friend WithEvents btnBack As Button
End Class
