﻿Public Class report_form
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblGrosspay.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles lblNetpay.Click

    End Sub
End Class