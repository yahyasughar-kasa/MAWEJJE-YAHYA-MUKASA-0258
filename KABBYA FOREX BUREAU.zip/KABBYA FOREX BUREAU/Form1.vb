﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblUGX1.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnConvertyuan_Click(sender As Object, e As EventArgs) Handles btnConvertyuan.Click

        Dim ugx As Double
        Dim yuan As Double

        If Double.TryParse(txtUGXYUAN1.Text, ugx) Then
            yuan = ugx / 540
            txtYuan1.Text = yuan.ToString("0.00")
        Else
            MessageBox.Show("Please enter a valid UGX amount.")
        End If
    End Sub

    Private Sub btnConvertUGXFromYuan_Click(sender As Object, e As EventArgs) Handles btnConvertUGXFromYuan.Click

        Dim yuan As Double
        Dim ugx As Double

        If Double.TryParse(txtYuanUGX2.Text, yuan) Then
            ugx = yuan * 540
            txtUGX2.Text = ugx.ToString("0.00")
        Else
            MessageBox.Show("Please enter a valid Chinese Yuan amount.")
        End If

    End Sub

    Private Sub btnConvertDirham3_Click(sender As Object, e As EventArgs) Handles btnConvertDirham3.Click


        Dim ugx As Double
        Dim dirham As Double

        If Double.TryParse(txtUGXDirham3.Text, ugx) Then
            dirham = ugx / 110
            txtDirham3.Text = dirham.ToString("0.00")
        Else
            MessageBox.Show("Please enter a valid UGX amount.")
        End If
    End Sub

    Private Sub btnConvertUGXFromDirham_Click(sender As Object, e As EventArgs) Handles btnConvertUGXFromDirham.Click

        Dim dirham As Double
        Dim ugx As Double

        If Double.TryParse(txtDirhamUGX4.Text, dirham) Then
            ugx = dirham * 110
            txtUGX4.Text = ugx.ToString("0.00")
        Else
            MessageBox.Show("Please enter a valid UAE Dirham amount.")
        End If
    End Sub

    Private Sub txtUGX4_TextChanged(sender As Object, e As EventArgs) Handles txtUGX4.TextChanged

    End Sub

    Private Sub lblUAEDIRHAM3_Click(sender As Object, e As EventArgs) Handles lblUAEDIRHAM3.Click

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtUGXYUAN1.Clear()
        txtYuan1.Clear()

        txtYuanUGX2.Clear()
        txtUGX2.Clear()

        txtUGXDirham3.Clear()
        txtUGX4.Clear()

        txtDirham3.Clear()
        txtDirhamUGX4.Clear()
    End Sub
End Class
