﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblUGX1 = New Label()
        lblCHINESEYUAN2 = New Label()
        lblCHINESEYUAN1 = New Label()
        lblUGX2 = New Label()
        lblUGX3 = New Label()
        lblUAEDIRHAM4 = New Label()
        lblUAEDIRHAM3 = New Label()
        lblUGX4 = New Label()
        txtUGXYUAN1 = New TextBox()
        txtYuanUGX2 = New TextBox()
        txtYuan1 = New TextBox()
        txtUGX2 = New TextBox()
        txtUGXDirham3 = New TextBox()
        txtDirham3 = New TextBox()
        txtDirhamUGX4 = New TextBox()
        txtUGX4 = New TextBox()
        btnConvertyuan = New Button()
        btnConvertUGXFromYuan = New Button()
        btnConvertDirham3 = New Button()
        btnConvertUGXFromDirham = New Button()
        lblKABBYAFOREXBUREAU = New Label()
        btnClear = New Button()
        SuspendLayout()
        ' 
        ' lblUGX1
        ' 
        lblUGX1.AutoSize = True
        lblUGX1.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        lblUGX1.Location = New Point(86, 86)
        lblUGX1.Name = "lblUGX1"
        lblUGX1.Size = New Size(35, 15)
        lblUGX1.TabIndex = 1
        lblUGX1.Text = "UGX1"
        ' 
        ' lblCHINESEYUAN2
        ' 
        lblCHINESEYUAN2.AutoSize = True
        lblCHINESEYUAN2.Font = New Font("Segoe UI Semibold", 9F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        lblCHINESEYUAN2.Location = New Point(75, 156)
        lblCHINESEYUAN2.Name = "lblCHINESEYUAN2"
        lblCHINESEYUAN2.Size = New Size(95, 15)
        lblCHINESEYUAN2.TabIndex = 2
        lblCHINESEYUAN2.Text = "CHINESE YUAN2"
        ' 
        ' lblCHINESEYUAN1
        ' 
        lblCHINESEYUAN1.AutoSize = True
        lblCHINESEYUAN1.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold Or FontStyle.Italic)
        lblCHINESEYUAN1.Location = New Point(584, 78)
        lblCHINESEYUAN1.Name = "lblCHINESEYUAN1"
        lblCHINESEYUAN1.Size = New Size(106, 17)
        lblCHINESEYUAN1.TabIndex = 3
        lblCHINESEYUAN1.Text = "CHINESE YUAN1"
        ' 
        ' lblUGX2
        ' 
        lblUGX2.AutoSize = True
        lblUGX2.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold Or FontStyle.Italic)
        lblUGX2.Location = New Point(620, 154)
        lblUGX2.Name = "lblUGX2"
        lblUGX2.Size = New Size(41, 17)
        lblUGX2.TabIndex = 4
        lblUGX2.Text = "UGX2"
        ' 
        ' lblUGX3
        ' 
        lblUGX3.AutoSize = True
        lblUGX3.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        lblUGX3.Location = New Point(86, 246)
        lblUGX3.Name = "lblUGX3"
        lblUGX3.Size = New Size(40, 17)
        lblUGX3.TabIndex = 5
        lblUGX3.Text = "UGX3"
        ' 
        ' lblUAEDIRHAM4
        ' 
        lblUAEDIRHAM4.AutoSize = True
        lblUAEDIRHAM4.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        lblUAEDIRHAM4.Location = New Point(66, 331)
        lblUAEDIRHAM4.Name = "lblUAEDIRHAM4"
        lblUAEDIRHAM4.Size = New Size(96, 17)
        lblUAEDIRHAM4.TabIndex = 6
        lblUAEDIRHAM4.Text = "UAE DIRHAM4"
        ' 
        ' lblUAEDIRHAM3
        ' 
        lblUAEDIRHAM3.AutoSize = True
        lblUAEDIRHAM3.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold Or FontStyle.Italic)
        lblUAEDIRHAM3.Location = New Point(595, 246)
        lblUAEDIRHAM3.Name = "lblUAEDIRHAM3"
        lblUAEDIRHAM3.Size = New Size(95, 17)
        lblUAEDIRHAM3.TabIndex = 7
        lblUAEDIRHAM3.Text = "UAE DIRHAM3"
        ' 
        ' lblUGX4
        ' 
        lblUGX4.AutoSize = True
        lblUGX4.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold Or FontStyle.Italic)
        lblUGX4.Location = New Point(620, 331)
        lblUGX4.Name = "lblUGX4"
        lblUGX4.Size = New Size(41, 17)
        lblUGX4.TabIndex = 8
        lblUGX4.Text = "UGX4"
        ' 
        ' txtUGXYUAN1
        ' 
        txtUGXYUAN1.Location = New Point(62, 104)
        txtUGXYUAN1.Multiline = True
        txtUGXYUAN1.Name = "txtUGXYUAN1"
        txtUGXYUAN1.Size = New Size(100, 39)
        txtUGXYUAN1.TabIndex = 9
        ' 
        ' txtYuanUGX2
        ' 
        txtYuanUGX2.Location = New Point(62, 174)
        txtYuanUGX2.Multiline = True
        txtYuanUGX2.Name = "txtYuanUGX2"
        txtYuanUGX2.Size = New Size(100, 46)
        txtYuanUGX2.TabIndex = 10
        ' 
        ' txtYuan1
        ' 
        txtYuan1.Location = New Point(590, 104)
        txtYuan1.Multiline = True
        txtYuan1.Name = "txtYuan1"
        txtYuan1.Size = New Size(100, 39)
        txtYuan1.TabIndex = 11
        ' 
        ' txtUGX2
        ' 
        txtUGX2.Location = New Point(590, 174)
        txtUGX2.Multiline = True
        txtUGX2.Name = "txtUGX2"
        txtUGX2.Size = New Size(100, 46)
        txtUGX2.TabIndex = 12
        ' 
        ' txtUGXDirham3
        ' 
        txtUGXDirham3.Location = New Point(62, 278)
        txtUGXDirham3.Multiline = True
        txtUGXDirham3.Name = "txtUGXDirham3"
        txtUGXDirham3.Size = New Size(100, 50)
        txtUGXDirham3.TabIndex = 13
        ' 
        ' txtDirham3
        ' 
        txtDirham3.Location = New Point(590, 277)
        txtDirham3.Multiline = True
        txtDirham3.Name = "txtDirham3"
        txtDirham3.Size = New Size(100, 51)
        txtDirham3.TabIndex = 14
        ' 
        ' txtDirhamUGX4
        ' 
        txtDirhamUGX4.Location = New Point(66, 351)
        txtDirhamUGX4.Multiline = True
        txtDirhamUGX4.Name = "txtDirhamUGX4"
        txtDirhamUGX4.Size = New Size(108, 52)
        txtDirhamUGX4.TabIndex = 15
        ' 
        ' txtUGX4
        ' 
        txtUGX4.Location = New Point(590, 350)
        txtUGX4.Multiline = True
        txtUGX4.Name = "txtUGX4"
        txtUGX4.Size = New Size(100, 52)
        txtUGX4.TabIndex = 16
        ' 
        ' btnConvertyuan
        ' 
        btnConvertyuan.Location = New Point(325, 78)
        btnConvertyuan.Name = "btnConvertyuan"
        btnConvertyuan.Size = New Size(145, 65)
        btnConvertyuan.TabIndex = 17
        btnConvertyuan.Text = "CONVERT TO YUAN"
        btnConvertyuan.UseVisualStyleBackColor = True
        ' 
        ' btnConvertUGXFromYuan
        ' 
        btnConvertUGXFromYuan.Location = New Point(325, 154)
        btnConvertUGXFromYuan.Name = "btnConvertUGXFromYuan"
        btnConvertUGXFromYuan.Size = New Size(145, 69)
        btnConvertUGXFromYuan.TabIndex = 18
        btnConvertUGXFromYuan.Text = "CONVERT TO UGX"
        btnConvertUGXFromYuan.UseVisualStyleBackColor = True
        ' 
        ' btnConvertDirham3
        ' 
        btnConvertDirham3.Location = New Point(325, 246)
        btnConvertDirham3.Name = "btnConvertDirham3"
        btnConvertDirham3.Size = New Size(145, 73)
        btnConvertDirham3.TabIndex = 19
        btnConvertDirham3.Text = "CONVERT TO DIRHAM"
        btnConvertDirham3.UseVisualStyleBackColor = True
        ' 
        ' btnConvertUGXFromDirham
        ' 
        btnConvertUGXFromDirham.Location = New Point(325, 339)
        btnConvertUGXFromDirham.Name = "btnConvertUGXFromDirham"
        btnConvertUGXFromDirham.Size = New Size(145, 58)
        btnConvertUGXFromDirham.TabIndex = 20
        btnConvertUGXFromDirham.Text = "CONVERT TO UGX"
        btnConvertUGXFromDirham.UseVisualStyleBackColor = True
        ' 
        ' lblKABBYAFOREXBUREAU
        ' 
        lblKABBYAFOREXBUREAU.AutoSize = True
        lblKABBYAFOREXBUREAU.Font = New Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblKABBYAFOREXBUREAU.Location = New Point(219, 23)
        lblKABBYAFOREXBUREAU.Name = "lblKABBYAFOREXBUREAU"
        lblKABBYAFOREXBUREAU.Size = New Size(327, 37)
        lblKABBYAFOREXBUREAU.TabIndex = 21
        lblKABBYAFOREXBUREAU.Text = "KABBYA FOREX BUREAU"
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(340, 403)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(106, 35)
        btnClear.TabIndex = 22
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(800, 450)
        Controls.Add(btnClear)
        Controls.Add(lblKABBYAFOREXBUREAU)
        Controls.Add(btnConvertUGXFromDirham)
        Controls.Add(btnConvertDirham3)
        Controls.Add(btnConvertUGXFromYuan)
        Controls.Add(btnConvertyuan)
        Controls.Add(txtUGX4)
        Controls.Add(txtDirhamUGX4)
        Controls.Add(txtDirham3)
        Controls.Add(txtUGXDirham3)
        Controls.Add(txtUGX2)
        Controls.Add(txtYuan1)
        Controls.Add(txtYuanUGX2)
        Controls.Add(txtUGXYUAN1)
        Controls.Add(lblUGX4)
        Controls.Add(lblUAEDIRHAM3)
        Controls.Add(lblUAEDIRHAM4)
        Controls.Add(lblUGX3)
        Controls.Add(lblUGX2)
        Controls.Add(lblCHINESEYUAN1)
        Controls.Add(lblCHINESEYUAN2)
        Controls.Add(lblUGX1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents lblUGX1 As Label
    Friend WithEvents lblCHINESEYUAN2 As Label
    Friend WithEvents lblCHINESEYUAN1 As Label
    Friend WithEvents lblUGX2 As Label
    Friend WithEvents lblUGX3 As Label
    Friend WithEvents lblUAEDIRHAM4 As Label
    Friend WithEvents lblUAEDIRHAM3 As Label
    Friend WithEvents lblUGX4 As Label
    Friend WithEvents txtUGXYUAN1 As TextBox
    Friend WithEvents txtYuanUGX2 As TextBox
    Friend WithEvents txtYuan1 As TextBox
    Friend WithEvents txtUGX2 As TextBox
    Friend WithEvents txtUGXDirham3 As TextBox
    Friend WithEvents txtDirham3 As TextBox
    Friend WithEvents txtDirhamUGX4 As TextBox
    Friend WithEvents txtUGX4 As TextBox
    Friend WithEvents btnConvertyuan As Button
    Friend WithEvents btnConvertUGXFromYuan As Button
    Friend WithEvents btnConvertDirham3 As Button
    Friend WithEvents btnConvertUGXFromDirham As Button
    Friend WithEvents lblKABBYAFOREXBUREAU As Label
    Friend WithEvents btnClear As Button

End Class
