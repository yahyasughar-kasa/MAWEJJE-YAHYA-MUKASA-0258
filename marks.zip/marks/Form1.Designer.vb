﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblTitle = New Label()
        lblMark = New Label()
        lblGrade = New Label()
        txtMark = New TextBox()
        txtGrade = New TextBox()
        btnEvaluate = New Button()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.Location = New Point(251, 31)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(317, 30)
        lblTitle.TabIndex = 0
        lblTitle.Text = "GRADING SCALE CALCULATOR"
        ' 
        ' lblMark
        ' 
        lblMark.AutoSize = True
        lblMark.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblMark.Location = New Point(251, 76)
        lblMark.Name = "lblMark"
        lblMark.Size = New Size(69, 15)
        lblMark.TabIndex = 1
        lblMark.Text = "Enter Mark"
        ' 
        ' lblGrade
        ' 
        lblGrade.AutoSize = True
        lblGrade.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblGrade.Location = New Point(251, 125)
        lblGrade.Name = "lblGrade"
        lblGrade.Size = New Size(41, 15)
        lblGrade.TabIndex = 2
        lblGrade.Text = "Grade"
        ' 
        ' txtMark
        ' 
        txtMark.Location = New Point(357, 73)
        txtMark.Name = "txtMark"
        txtMark.Size = New Size(189, 23)
        txtMark.TabIndex = 3
        ' 
        ' txtGrade
        ' 
        txtGrade.Location = New Point(357, 125)
        txtGrade.Name = "txtGrade"
        txtGrade.Size = New Size(189, 23)
        txtGrade.TabIndex = 4
        ' 
        ' btnEvaluate
        ' 
        btnEvaluate.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnEvaluate.Location = New Point(357, 170)
        btnEvaluate.Name = "btnEvaluate"
        btnEvaluate.Size = New Size(75, 42)
        btnEvaluate.TabIndex = 5
        btnEvaluate.Text = "Evaluate"
        btnEvaluate.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(800, 450)
        Controls.Add(btnEvaluate)
        Controls.Add(txtGrade)
        Controls.Add(txtMark)
        Controls.Add(lblGrade)
        Controls.Add(lblMark)
        Controls.Add(lblTitle)
        Name = "Form1"
        Text = "Grade Calculator"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents lblMark As Label
    Friend WithEvents lblGrade As Label
    Friend WithEvents txtMark As TextBox
    Friend WithEvents txtGrade As TextBox
    Friend WithEvents btnEvaluate As Button

    Private Sub btnEvaluate_Click(sender As Object, e As EventArgs) Handles btnEvaluate.Click

        Dim Mark As Integer

        'Validate that a mark has been entered
        If txtMark.Text = "" Then
            MessageBox.Show("Please enter the mark.")
            txtMark.Focus()
            Exit Sub
        End If

        'Check that the mark is numeric
        If Not Integer.TryParse(txtMark.Text, Mark) Then
            MessageBox.Show("Please enter a valid numerical mark.")
            txtMark.Focus()
            Exit Sub
        End If

        'Validate mark range
        If Mark > 100 Then
            MessageBox.Show("wrong entry, please re-enter the mark.")
            txtMark.Clear()
            txtGrade.Clear()
            txtMark.Focus()
            Exit Sub
        End If

        If Mark < 0 Then
            MessageBox.Show("wrong entry, please re-enter the mark.")
            txtMark.Clear()
            txtGrade.Clear()
            txtMark.Focus()
            Exit Sub
        End If

        'Determine the grade using Select Case
        Select Case Mark

            Case 90 To 100
                txtGrade.Text = "Excellent"

            Case 80 To 89
                txtGrade.Text = "Very Good"

            Case 70 To 79
                txtGrade.Text = "Good"

            Case 60 To 69
                txtGrade.Text = "Medium"

            Case 50 To 59
                txtGrade.Text = "Pass"

            Case 0 To 49
                txtGrade.Text = "Fail"

        End Select

    End Sub
End Class
