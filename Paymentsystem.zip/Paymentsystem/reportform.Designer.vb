﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class reportform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtGrosspay = New TextBox()
        txtNetpay = New TextBox()
        lblGrosspay = New Label()
        lblNetpay = New Label()
        btnBack = New Button()
        SuspendLayout()
        ' 
        ' txtGrosspay
        ' 
        txtGrosspay.Location = New Point(246, 58)
        txtGrosspay.Name = "txtGrosspay"
        txtGrosspay.Size = New Size(100, 23)
        txtGrosspay.TabIndex = 0
        ' 
        ' txtNetpay
        ' 
        txtNetpay.Location = New Point(246, 107)
        txtNetpay.Name = "txtNetpay"
        txtNetpay.Size = New Size(100, 23)
        txtNetpay.TabIndex = 1
        ' 
        ' lblGrosspay
        ' 
        lblGrosspay.AutoSize = True
        lblGrosspay.Location = New Point(182, 58)
        lblGrosspay.Name = "lblGrosspay"
        lblGrosspay.Size = New Size(55, 15)
        lblGrosspay.TabIndex = 2
        lblGrosspay.Text = "Grosspay"
        ' 
        ' lblNetpay
        ' 
        lblNetpay.AutoSize = True
        lblNetpay.Location = New Point(182, 110)
        lblNetpay.Name = "lblNetpay"
        lblNetpay.Size = New Size(45, 15)
        lblNetpay.TabIndex = 3
        lblNetpay.Text = "Netpay"
        ' 
        ' btnBack
        ' 
        btnBack.Location = New Point(243, 148)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(75, 23)
        btnBack.TabIndex = 4
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = True
        ' 
        ' reportform
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btnBack)
        Controls.Add(lblNetpay)
        Controls.Add(lblGrosspay)
        Controls.Add(txtNetpay)
        Controls.Add(txtGrosspay)
        Name = "reportform"
        Text = "reportform"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtGrosspay As TextBox
    Friend WithEvents txtNetpay As TextBox
    Friend WithEvents lblGrosspay As Label
    Friend WithEvents lblNetpay As Label
    Friend WithEvents btnBack As Button
End Class
