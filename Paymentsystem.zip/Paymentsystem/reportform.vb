﻿Public Class reportform
    Private Sub reportform_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtGrosspay.Text = Dataform.GrossPay
        txtNetpay.Text = Dataform.NetPay.ToString("N2")

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click

        Dataform.Show()
        Me.Hide()

    End Sub

End Class