﻿
Public Class Dataform

        Public EmployeeName As String
        Public BasicPay As Double
        Public MedicalAllowance As Double
        Public GrossPay As Double
        Public NSSF As Double
        Public NetPay As Double

        Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

            'Check empty fields
            If txtEmployeeName.Text = "" Or
           txtBasicpay.Text = "" Or
           txtMedicalallowance.Text = "" Then

                MessageBox.Show("Please enter all employee information.")
                Exit Sub
            End If

            'Check whether pay values are numbers
            If Not IsNumeric(txtBasicpay.Text) Or
           Not IsNumeric(txtMedicalallowance.Text) Then

                MessageBox.Show("Please enter valid amounts.")
                Exit Sub
            End If

            'Get values
            EmployeeName = txtEmployeeName.Text
            BasicPay = CDbl(txtBasicpay.Text)
            MedicalAllowance = CDbl(txtMedicalallowance.Text)

            'Calculate Gross Pay
            GrossPay = BasicPay + MedicalAllowance

            'Calculate NSSF (5%)
            NSSF = GrossPay * 0.05

            'Calculate Net Pay
            NetPay = GrossPay - NSSF

            'Open report form
            Reportform.Show()
            Me.Hide()

        End Sub

    End Class