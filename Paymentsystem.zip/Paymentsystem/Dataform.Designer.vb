﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dataform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblTitle = New Label()
        lblEmployeeName = New Label()
        lblBasicpay = New Label()
        lblMedicalallowance = New Label()
        btnCalculate = New Button()
        txtEmployeeName = New TextBox()
        txtBasicpay = New TextBox()
        txtMedicalallowance = New TextBox()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Location = New Point(319, 32)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(109, 15)
        lblTitle.TabIndex = 0
        lblTitle.Text = "DATA ENTRY FORM"
        ' 
        ' lblEmployeeName
        ' 
        lblEmployeeName.AutoSize = True
        lblEmployeeName.Location = New Point(178, 76)
        lblEmployeeName.Name = "lblEmployeeName"
        lblEmployeeName.Size = New Size(94, 15)
        lblEmployeeName.TabIndex = 1
        lblEmployeeName.Text = "Employee Name"
        ' 
        ' lblBasicpay
        ' 
        lblBasicpay.AutoSize = True
        lblBasicpay.Location = New Point(178, 127)
        lblBasicpay.Name = "lblBasicpay"
        lblBasicpay.Size = New Size(56, 15)
        lblBasicpay.TabIndex = 2
        lblBasicpay.Text = "Basic pay"
        ' 
        ' lblMedicalallowance
        ' 
        lblMedicalallowance.AutoSize = True
        lblMedicalallowance.Location = New Point(178, 184)
        lblMedicalallowance.Name = "lblMedicalallowance"
        lblMedicalallowance.Size = New Size(105, 15)
        lblMedicalallowance.TabIndex = 3
        lblMedicalallowance.Text = "Medical allowance"
        ' 
        ' btnCalculate
        ' 
        btnCalculate.Location = New Point(265, 237)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(148, 45)
        btnCalculate.TabIndex = 4
        btnCalculate.Text = "Calculate"
        btnCalculate.UseVisualStyleBackColor = True
        ' 
        ' txtEmployeeName
        ' 
        txtEmployeeName.Location = New Point(279, 74)
        txtEmployeeName.Name = "txtEmployeeName"
        txtEmployeeName.Size = New Size(179, 23)
        txtEmployeeName.TabIndex = 5
        ' 
        ' txtBasicpay
        ' 
        txtBasicpay.Location = New Point(289, 127)
        txtBasicpay.Name = "txtBasicpay"
        txtBasicpay.Size = New Size(179, 23)
        txtBasicpay.TabIndex = 6
        ' 
        ' txtMedicalallowance
        ' 
        txtMedicalallowance.Location = New Point(289, 181)
        txtMedicalallowance.Name = "txtMedicalallowance"
        txtMedicalallowance.Size = New Size(179, 23)
        txtMedicalallowance.TabIndex = 7
        ' 
        ' Dataform
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtMedicalallowance)
        Controls.Add(txtBasicpay)
        Controls.Add(txtEmployeeName)
        Controls.Add(btnCalculate)
        Controls.Add(lblMedicalallowance)
        Controls.Add(lblBasicpay)
        Controls.Add(lblEmployeeName)
        Controls.Add(lblTitle)
        Name = "Dataform"
        Text = "Dataform"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents lblEmployeeName As Label
    Friend WithEvents lblBasicpay As Label
    Friend WithEvents lblMedicalallowance As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents txtEmployeeName As TextBox
    Friend WithEvents txtBasicpay As TextBox
    Friend WithEvents txtMedicalallowance As TextBox
End Class
