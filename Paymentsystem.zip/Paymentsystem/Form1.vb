﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles lblPassword.Click

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        If txtUsername.Text = "Accounts" And txtPassword.Text = "pass123" Then

            dataform.Show()
            Me.Hide()

        Else

            MessageBox.Show("Incorrect username/password",
                        "Login Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error)

        End If

    End Sub
End Class
