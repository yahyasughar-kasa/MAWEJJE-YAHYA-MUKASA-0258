﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblServiceFee = New Label()
        lblVAT = New Label()
        lblFixedChargesTotal = New Label()
        lblUnitsPurchased = New Label()
        btnFixedChargesTotal = New Button()
        lblTotalCost = New Label()
        btnTotalcost = New Button()
        txtServiceFee = New TextBox()
        txtVAT = New TextBox()
        txtFixedChargesTotal = New TextBox()
        txtUnitsPurchased = New TextBox()
        txtTotalCost = New TextBox()
        SuspendLayout()
        ' 
        ' lblServiceFee
        ' 
        lblServiceFee.AutoSize = True
        lblServiceFee.Location = New Point(100, 23)
        lblServiceFee.Name = "lblServiceFee"
        lblServiceFee.Size = New Size(65, 15)
        lblServiceFee.TabIndex = 0
        lblServiceFee.Text = "Service Fee"
        ' 
        ' lblVAT
        ' 
        lblVAT.AutoSize = True
        lblVAT.Location = New Point(100, 63)
        lblVAT.Name = "lblVAT"
        lblVAT.Size = New Size(26, 15)
        lblVAT.TabIndex = 1
        lblVAT.Text = "VAT"
        ' 
        ' lblFixedChargesTotal
        ' 
        lblFixedChargesTotal.AutoSize = True
        lblFixedChargesTotal.Location = New Point(100, 146)
        lblFixedChargesTotal.Name = "lblFixedChargesTotal"
        lblFixedChargesTotal.Size = New Size(109, 15)
        lblFixedChargesTotal.TabIndex = 2
        lblFixedChargesTotal.Text = "Fixed Charges Total"
        ' 
        ' lblUnitsPurchased
        ' 
        lblUnitsPurchased.AutoSize = True
        lblUnitsPurchased.Location = New Point(100, 183)
        lblUnitsPurchased.Name = "lblUnitsPurchased"
        lblUnitsPurchased.Size = New Size(92, 15)
        lblUnitsPurchased.TabIndex = 3
        lblUnitsPurchased.Text = "Units Purchased"
        ' 
        ' btnFixedChargesTotal
        ' 
        btnFixedChargesTotal.Location = New Point(187, 110)
        btnFixedChargesTotal.Name = "btnFixedChargesTotal"
        btnFixedChargesTotal.Size = New Size(212, 23)
        btnFixedChargesTotal.TabIndex = 4
        btnFixedChargesTotal.Text = "FIXED CHARGES TOTAL"
        btnFixedChargesTotal.UseVisualStyleBackColor = True
        ' 
        ' lblTotalCost
        ' 
        lblTotalCost.AutoSize = True
        lblTotalCost.Location = New Point(100, 268)
        lblTotalCost.Name = "lblTotalCost"
        lblTotalCost.Size = New Size(71, 15)
        lblTotalCost.TabIndex = 5
        lblTotalCost.Text = "TOTAL COST"
        ' 
        ' btnTotalcost
        ' 
        btnTotalcost.Location = New Point(187, 228)
        btnTotalcost.Name = "btnTotalcost"
        btnTotalcost.Size = New Size(212, 23)
        btnTotalcost.TabIndex = 6
        btnTotalcost.Text = "TOTAL COST"
        btnTotalcost.UseVisualStyleBackColor = True
        ' 
        ' txtServiceFee
        ' 
        txtServiceFee.Location = New Point(187, 20)
        txtServiceFee.Name = "txtServiceFee"
        txtServiceFee.Size = New Size(189, 23)
        txtServiceFee.TabIndex = 7
        ' 
        ' txtVAT
        ' 
        txtVAT.Location = New Point(187, 55)
        txtVAT.Name = "txtVAT"
        txtVAT.Size = New Size(189, 23)
        txtVAT.TabIndex = 8
        ' 
        ' txtFixedChargesTotal
        ' 
        txtFixedChargesTotal.Location = New Point(215, 139)
        txtFixedChargesTotal.Name = "txtFixedChargesTotal"
        txtFixedChargesTotal.Size = New Size(161, 23)
        txtFixedChargesTotal.TabIndex = 9
        ' 
        ' txtUnitsPurchased
        ' 
        txtUnitsPurchased.Location = New Point(215, 180)
        txtUnitsPurchased.Name = "txtUnitsPurchased"
        txtUnitsPurchased.Size = New Size(161, 23)
        txtUnitsPurchased.TabIndex = 10
        ' 
        ' txtTotalCost
        ' 
        txtTotalCost.Location = New Point(187, 260)
        txtTotalCost.Name = "txtTotalCost"
        txtTotalCost.Size = New Size(100, 23)
        txtTotalCost.TabIndex = 11
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtTotalCost)
        Controls.Add(txtUnitsPurchased)
        Controls.Add(txtFixedChargesTotal)
        Controls.Add(txtVAT)
        Controls.Add(txtServiceFee)
        Controls.Add(btnTotalcost)
        Controls.Add(lblTotalCost)
        Controls.Add(btnFixedChargesTotal)
        Controls.Add(lblUnitsPurchased)
        Controls.Add(lblFixedChargesTotal)
        Controls.Add(lblVAT)
        Controls.Add(lblServiceFee)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblServiceFee As Label
    Friend WithEvents lblVAT As Label
    Friend WithEvents lblFixedChargesTotal As Label
    Friend WithEvents lblUnitsPurchased As Label
    Friend WithEvents btnFixedChargesTotal As Button
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents btnTotalcost As Button
    Friend WithEvents txtServiceFee As TextBox
    Friend WithEvents txtVAT As TextBox
    Friend WithEvents txtFixedChargesTotal As TextBox
    Friend WithEvents txtUnitsPurchased As TextBox
    Friend WithEvents txtTotalCost As TextBox

    Private Sub btnFixedChargesTotal_Click(sender As Object, e As EventArgs) Handles btnFixedChargesTotal.Click

        txtServiceFee.Text = "3800"
        txtVAT.Text = "1730"

        Dim serviceFee As Double
        Dim vat As Double
        Dim fixedCharges As Double

        serviceFee = Val(txtServiceFee.Text)
        vat = Val(txtVAT.Text)

        fixedCharges = serviceFee + vat

        txtFixedChargesTotal.Text = fixedCharges.ToString("")

    End Sub

    Private Sub btnTotalcost_Click(sender As Object, e As EventArgs) Handles btnTotalcost.Click

        Dim units As Double
        Dim costPerUnit As Double
        Dim fixedCharges As Double
        Dim totalCost As Double

        units = Val(txtUnitsPurchased.Text)
        costPerUnit = 780
        fixedCharges = Val(txtFixedChargesTotal.Text)

        totalCost = (units * costPerUnit) + fixedCharges

        txtTotalCost.Text = totalCost.ToString("N0")

    End Sub

End Class
