﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        cboBookType = New ComboBox()
        lblBookType = New Label()
        lblPrice = New Label()
        lblQuantity = New Label()
        lblTotalCost = New Label()
        txtPrice = New TextBox()
        txtTotalCost = New TextBox()
        txtQuantity = New TextBox()
        btnComputeSales = New Button()
        btnClear = New Button()
        SuspendLayout()
        ' 
        ' cboBookType
        ' 
        cboBookType.FormattingEnabled = True
        cboBookType.Location = New Point(226, 27)
        cboBookType.Name = "cboBookType"
        cboBookType.Size = New Size(237, 23)
        cboBookType.TabIndex = 0
        ' 
        ' lblBookType
        ' 
        lblBookType.AutoSize = True
        lblBookType.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblBookType.Location = New Point(130, 27)
        lblBookType.Name = "lblBookType"
        lblBookType.Size = New Size(72, 17)
        lblBookType.TabIndex = 1
        lblBookType.Text = "Book Type"
        ' 
        ' lblPrice
        ' 
        lblPrice.AutoSize = True
        lblPrice.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblPrice.Location = New Point(130, 77)
        lblPrice.Name = "lblPrice"
        lblPrice.Size = New Size(79, 17)
        lblPrice.TabIndex = 2
        lblPrice.Text = "Price (UGX)"
        ' 
        ' lblQuantity
        ' 
        lblQuantity.AutoSize = True
        lblQuantity.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblQuantity.Location = New Point(130, 133)
        lblQuantity.Name = "lblQuantity"
        lblQuantity.Size = New Size(62, 17)
        lblQuantity.TabIndex = 3
        lblQuantity.Text = "Quantity"
        ' 
        ' lblTotalCost
        ' 
        lblTotalCost.AutoSize = True
        lblTotalCost.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTotalCost.Location = New Point(130, 178)
        lblTotalCost.Name = "lblTotalCost"
        lblTotalCost.Size = New Size(111, 17)
        lblTotalCost.TabIndex = 4
        lblTotalCost.Text = "Total Cost (UGX)"
        ' 
        ' txtPrice
        ' 
        txtPrice.Location = New Point(244, 71)
        txtPrice.Name = "txtPrice"
        txtPrice.Size = New Size(237, 23)
        txtPrice.TabIndex = 5
        ' 
        ' txtTotalCost
        ' 
        txtTotalCost.Location = New Point(247, 172)
        txtTotalCost.Name = "txtTotalCost"
        txtTotalCost.Size = New Size(237, 23)
        txtTotalCost.TabIndex = 6
        txtTotalCost.Text = vbCrLf
        ' 
        ' txtQuantity
        ' 
        txtQuantity.Location = New Point(247, 127)
        txtQuantity.Name = "txtQuantity"
        txtQuantity.Size = New Size(234, 23)
        txtQuantity.TabIndex = 7
        ' 
        ' btnComputeSales
        ' 
        btnComputeSales.Font = New Font("Book Antiqua", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnComputeSales.Location = New Point(293, 212)
        btnComputeSales.Name = "btnComputeSales"
        btnComputeSales.Size = New Size(102, 45)
        btnComputeSales.TabIndex = 8
        btnComputeSales.Text = "Compute Sales"
        btnComputeSales.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClear.Location = New Point(304, 263)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(75, 41)
        btnClear.TabIndex = 9
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.GradientActiveCaption
        ClientSize = New Size(800, 450)
        Controls.Add(btnClear)
        Controls.Add(btnComputeSales)
        Controls.Add(txtQuantity)
        Controls.Add(txtTotalCost)
        Controls.Add(txtPrice)
        Controls.Add(lblTotalCost)
        Controls.Add(lblQuantity)
        Controls.Add(lblPrice)
        Controls.Add(lblBookType)
        Controls.Add(cboBookType)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents cboBookType As ComboBox
    Friend WithEvents lblBookType As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents lblQuantity As Label
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents txtTotalCost As TextBox
    Friend WithEvents txtQuantity As TextBox
    Friend WithEvents btnComputeSales As Button
    Friend WithEvents btnClear As Button

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboBookType.Items.Add("Textbook")
        cboBookType.Items.Add("Novel")
        cboBookType.Items.Add("Magazine")

        txtPrice.ReadOnly = True
        txtTotalCost.ReadOnly = True


    End Sub

    Private Sub cboBookType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboBookType.SelectedIndexChanged

        Select Case cboBookType.SelectedItem.ToString()

            Case "Textbook"
                txtPrice.Text = "40000"

            Case "Novel"
                txtPrice.Text = "25000"

            Case "Magazine"
                txtPrice.Text = "10000"

        End Select



    End Sub

    Private Sub btnComputeSales_Click(sender As Object, e As EventArgs) Handles btnComputeSales.Click

        Dim price As Decimal
        Dim quantity As Integer
        Dim totalCost As Decimal

        If cboBookType.SelectedIndex = -1 Then
            MessageBox.Show("Please select a book type.")
            Exit Sub
        End If

        If Not Decimal.TryParse(txtPrice.Text, price) Then
            MessageBox.Show("Invalid price")
            Exit Sub
        End If

        If Not Integer.TryParse(txtQuantity.Text, quantity) Then
            MessageBox.Show("Please enter a valid quantity.")
            Exit Sub
        End If

        If quantity <= 0 Then
            MessageBox.Show("Quantity should be grter than zero.")
            Exit Sub
        End If

        totalCost = price * quantity

        txtTotalCost.Text = totalCost.ToString("")

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        cboBookType.SelectedIndex = -1
        txtPrice.Clear()
        txtQuantity.Clear()
        txtTotalCost.Clear()

        txtQuantity.Focus()

    End Sub

    Private Sub txtQuantity_TextChanged(sender As Object, e As EventArgs) Handles txtQuantity.TextChanged

    End Sub
End Class
